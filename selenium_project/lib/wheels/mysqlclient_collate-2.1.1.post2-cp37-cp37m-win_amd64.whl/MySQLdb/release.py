
__author__ = "CodeRed LLC <info@coderedcorp.com>"
version_info = (2,1,1,'post',2)
__version__ = "2.1.1.post2"
